
// Typing Animation
const typewriter = new Typewriter('#heroTitle', {
    loop: true,
    delay: 75,
});

typewriter.typeString('Hi, I\'m Marc')
    .pauseFor(1000)
    .deleteAll()
    .typeString('Creative Developer & Designer')
    .pauseFor(1000)
    .start();

// Sidebar toggle
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');
hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('open');
});

// Tilt init
VanillaTilt.init(document.querySelectorAll(".card"), {
    max: 15,
    speed: 400,
    glare: true,
    "max-glare": 0.3,
});

// Hero animation
gsap.from("#heroTitle", {
    duration: 1.2,
    y: -50,
    opacity: 0,
    ease: "power3.out"
});
gsap.from("#heroSubtitle", {
    duration: 1.2,
    delay: 0.3,
    y: 50,
    opacity: 0,
    ease: "power3.out"
});

// Scroll animations for cards
const cards = document.querySelectorAll('.card');
cards.forEach((card, i) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: card,
            start: "top 90%",
        },
        duration: 0.8,
        y: 30,
        opacity: 0,
        ease: "power2.out",
        delay: i * 0.1
    });
});

gsap.registerPlugin(ScrollTrigger);